class Main{
   public static void main(String[] args) {
      JogoDaVida partida = new JogoDaVida();
      partida.iniciarJogo();
   }
}